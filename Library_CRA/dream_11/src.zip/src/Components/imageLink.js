export const bg =
    "https://cdnflags.dream11.com/d11-static-pages/images/player-one-aug23-2x-sept.webp";
  export const logo =
    "https://cdnflags.dream11.com/d11-static-pages/images/dream11LogoWhite.webp";